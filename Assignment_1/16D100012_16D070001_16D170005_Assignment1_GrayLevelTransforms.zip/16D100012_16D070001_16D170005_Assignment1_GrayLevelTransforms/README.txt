By 
Parthasarathi Khirwadkar - 16D070001
Bhishma Dedhia - 16D170005
Sarthak Consul -16D100012

About Q2
Run the myMainscript.mlx file for the question
The hist_visualisation.m is a tool to obtain the local histogram about a point in a greyscale image. It was used to estimate CLAHE h parameter.


